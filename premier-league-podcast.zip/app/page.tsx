
"use client";
import PremierLeaguePodcast from "../components/PremierLeaguePodcast";

export default function Home() {
  return <PremierLeaguePodcast />;
}
